from .bing import Bing
