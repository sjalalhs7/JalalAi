class NeuronExceptions(Exception):
    pass
